# Bloom the Desert

This data pack is built for a Single Biome: Desert playthrough.
Its purpose is to provide a way for players to turn their desert
villages into Oasis.

- Creates a "botanist" villager variant with the appearance of a Swamp Farmer.
